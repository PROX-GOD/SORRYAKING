kalo cp gimana? yap benar, oprek user-agent nya
